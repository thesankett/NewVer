try {
    var sequenceId = configData04.presentations[configData04.presentationIndex];
} catch (e) {
    console.log('OCE environment not found');
}

$('.navigation li, .plusBtn, .verkaziaLogo').on(touchEvent, Tap(function (e) {
    if (!$(this).attr('data-Link')) {
        openPopup($(this).attr('data-Popup'));
    } else {
        slideOpen(sequenceId.sequences[$(this).attr('data-Link')].id, '01_index.html');
    }
}, '', touchEvent));

function openPopup(popupName) {
    closeAllPopup();
    $('.' + popupName).fadeIn(500);
}

function closeAllPopup() {
    $('.popup1').fadeOut();
}

$('.closePopup').on(touchEvent, Tap(function (e) {
    closeAllPopup();
}, '', touchEvent));