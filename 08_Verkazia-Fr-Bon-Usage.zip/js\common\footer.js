try {
    var sequenceId = configData08.presentations[configData08.presentationIndex];
} catch (e) {
    console.log('OCE environment not found');
}

$('.navigation li, .verkaziaLogo').on(touchEvent, Tap(function (e) {
    slideOpen(sequenceId.sequences[$(this).attr('data-Link')].id, '01_index.html');
}, '', touchEvent));