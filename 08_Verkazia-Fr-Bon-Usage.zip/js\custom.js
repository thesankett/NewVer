Scrollbar.init(document.getElementById("scrolldiv"), {
    alwaysShowTracks: true
});

function pageLoad() { }

function pageLeave() { }

var allfunctionDisappearing = function allfunctionDisappearing() {
    pageLeave();
}

var allfunctionAppearing = function allfunctionAppearing() {
    pageLoad();
}
onviewdisappearing('', allfunctionDisappearing);
onviewappearing('', allfunctionAppearing);